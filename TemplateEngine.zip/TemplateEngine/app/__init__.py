"""Standalone Terraform generation service."""
