from __future__ import annotations

import difflib
from dataclasses import dataclass


@dataclass(frozen=True)
class AzureResource:
    name: str
    category: str
    azurerm_types: tuple[str, ...]
    aliases: tuple[str, ...] = ()


class UnknownAzureResource(ValueError):
    """Admin asked Copilot to generate a name that is not a known Azure resource."""


# Canonical Azure products this portal will generate. Aliases include common typos-adjacent
# names, ARM types, and azurerm resource labels.
_RESOURCES: tuple[AzureResource, ...] = (
    AzureResource("Storage Account", "Storage", ("azurerm_storage_account",), ("blob storage", "azure storage", "storageaccount", "microsoft.storage/storageaccounts")),
    AzureResource("Storage Container", "Storage", ("azurerm_storage_container",), ("blob container",)),
    AzureResource("Managed Disk", "Storage", ("azurerm_managed_disk",), ("disk", "os disk")),
    AzureResource("Recovery Services Vault", "Storage", ("azurerm_recovery_services_vault",), ("backup vault", "rsv")),
    AzureResource("Virtual Machine", "Compute", ("azurerm_linux_virtual_machine", "azurerm_windows_virtual_machine"), ("vm", "azure vm", "virtualmachine", "microsoft.compute/virtualmachines")),
    AzureResource("Virtual Machine Scale Set", "Compute", ("azurerm_linux_virtual_machine_scale_set", "azurerm_windows_virtual_machine_scale_set"), ("vmss", "scale set")),
    AzureResource("App Service", "Compute", ("azurerm_linux_web_app", "azurerm_windows_web_app", "azurerm_service_plan"), ("web app", "app service plan", "azure app service", "microsoft.web/sites")),
    AzureResource("Function App", "Compute", ("azurerm_linux_function_app", "azurerm_windows_function_app"), ("azure functions", "functions")),
    AzureResource("Container Apps", "Compute", ("azurerm_container_app", "azurerm_container_app_environment"), ("container app", "aca")),
    AzureResource("Container Instance", "Compute", ("azurerm_container_group",), ("aci", "container instances")),
    AzureResource("Azure Kubernetes Service", "Compute", ("azurerm_kubernetes_cluster",), ("aks", "kubernetes", "k8s")),
    AzureResource("Static Web App", "Compute", ("azurerm_static_web_app",), ("static webapp",)),
    AzureResource("Virtual Network", "Networking", ("azurerm_virtual_network",), ("vnet", "microsoft.network/virtualnetworks")),
    AzureResource("Subnet", "Networking", ("azurerm_subnet",), ()),
    AzureResource("Network Security Group", "Networking", ("azurerm_network_security_group",), ("nsg",)),
    AzureResource("Public IP", "Networking", ("azurerm_public_ip",), ("pip", "public ip address")),
    AzureResource("Load Balancer", "Networking", ("azurerm_lb",), ("azure load balancer",)),
    AzureResource("Application Gateway", "Networking", ("azurerm_application_gateway",), ("app gateway", "appgw")),
    AzureResource("NAT Gateway", "Networking", ("azurerm_nat_gateway",), ()),
    AzureResource("VPN Gateway", "Networking", ("azurerm_virtual_network_gateway",), ("vnet gateway",)),
    AzureResource("Azure Firewall", "Networking", ("azurerm_firewall",), ("firewall",)),
    AzureResource("Private Endpoint", "Networking", ("azurerm_private_endpoint",), ()),
    AzureResource("Private DNS Zone", "Networking", ("azurerm_private_dns_zone",), ()),
    AzureResource("DNS Zone", "Networking", ("azurerm_dns_zone",), ("dns",)),
    AzureResource("Bastion", "Networking", ("azurerm_bastion_host",), ("azure bastion",)),
    AzureResource("Front Door", "Networking", ("azurerm_cdn_frontdoor_profile", "azurerm_cdn_frontdoor_endpoint"), ("frontdoor", "azure front door")),
    AzureResource("Key Vault", "Identity", ("azurerm_key_vault",), ("keyvault", "kv", "microsoft.keyvault/vaults")),
    AzureResource("User Assigned Identity", "Identity", ("azurerm_user_assigned_identity",), ("managed identity", "uai")),
    AzureResource("SQL Database", "Databases", ("azurerm_mssql_server", "azurerm_mssql_database"), ("azure sql", "sql db", "sql server", "microsoft.sql/servers")),
    AzureResource("MySQL Flexible Server", "Databases", ("azurerm_mysql_flexible_server",), ("mysql", "azure mysql")),
    AzureResource("PostgreSQL Flexible Server", "Databases", ("azurerm_postgresql_flexible_server",), ("postgres", "postgresql", "azure database for postgresql")),
    AzureResource("Cosmos DB", "Databases", ("azurerm_cosmosdb_account",), ("cosmos", "cosmosdb")),
    AzureResource("Redis Cache", "Databases", ("azurerm_redis_cache",), ("azure cache for redis", "redis")),
    AzureResource("Log Analytics Workspace", "Monitor", ("azurerm_log_analytics_workspace",), ("log analytics", "law")),
    AzureResource("Application Insights", "Monitor", ("azurerm_application_insights",), ("app insights",)),
    AzureResource("Container Registry", "Containers", ("azurerm_container_registry",), ("acr",)),
    AzureResource("Service Bus Namespace", "Integration", ("azurerm_servicebus_namespace",), ("service bus",)),
    AzureResource("Event Hub Namespace", "Integration", ("azurerm_eventhub_namespace",), ("event hubs", "eventhub")),
    AzureResource("API Management", "Integration", ("azurerm_api_management",), ("apim",)),
    AzureResource("Logic App", "Integration", ("azurerm_logic_app_workflow", "azurerm_logic_app_standard"), ("logic apps",)),
    AzureResource("Event Grid Topic", "Integration", ("azurerm_eventgrid_topic",), ("event grid",)),
    AzureResource("Data Factory", "Analytics", ("azurerm_data_factory",), ("adf",)),
    AzureResource("Databricks Workspace", "Analytics", ("azurerm_databricks_workspace",), ("databricks",)),
    AzureResource("Synapse Workspace", "Analytics", ("azurerm_synapse_workspace",), ("synapse",)),
    AzureResource("Cognitive Services", "AI", ("azurerm_cognitive_account",), ("openai", "azure openai", "ai services", "cognitive account")),
    AzureResource("AI Search", "AI", ("azurerm_search_service",), ("cognitive search", "azure search", "search service")),
    AzureResource("Resource Group", "Foundation", ("azurerm_resource_group",), ("rg", "resourcegroup")),
)


def _norm(value: str) -> str:
    return "".join(ch for ch in value.lower() if ch.isalnum())


def _index() -> dict[str, AzureResource]:
    mapping: dict[str, AzureResource] = {}
    for item in _RESOURCES:
        keys = [item.name, *item.azurerm_types, *item.aliases]
        for key in keys:
            mapping.setdefault(_norm(key), item)
            if key.startswith("azurerm_"):
                mapping.setdefault(_norm(key.removeprefix("azurerm_")), item)
    return mapping


_INDEX = _index()
_NAMES = [item.name for item in _RESOURCES]


def resolve_azure_resource(raw: str) -> AzureResource:
    text = (raw or "").strip()
    if not text:
        raise UnknownAzureResource("Resource type is required.")
    direct = _INDEX.get(_norm(text))
    if direct:
        return direct
    suggestions = difflib.get_close_matches(text, _NAMES, n=3, cutoff=0.55)
    extra = difflib.get_close_matches(_norm(text), list(_INDEX.keys()), n=3, cutoff=0.72)
    for key in extra:
        name = _INDEX[key].name
        if name not in suggestions:
            suggestions.append(name)
    hint = f" Did you mean: {', '.join(suggestions[:3])}?" if suggestions else ""
    examples = "Storage Account, App Service, Key Vault, AKS"
    raise UnknownAzureResource(
        f"'{text}' is not a recognized Azure resource. Copilot will not generate a template.{hint} "
        f"Use a real Azure product name such as {examples}."
    )


def list_azure_resources() -> tuple[AzureResource, ...]:
    return _RESOURCES


def known_azurerm_types() -> set[str]:
    types: set[str] = set()
    for item in _RESOURCES:
        types.update(item.azurerm_types)
    return types
