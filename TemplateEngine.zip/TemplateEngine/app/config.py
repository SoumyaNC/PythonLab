from __future__ import annotations

import os
from pathlib import Path

from pydantic import BaseModel
from dotenv import load_dotenv

ENGINE_DIR = Path(__file__).resolve().parents[1]
REPO_ROOT = ENGINE_DIR.parent


def _load_env_files() -> None:
    load_dotenv(ENGINE_DIR / ".env", override=False)


_load_env_files()


def _clean_token(raw: str | None) -> str | None:
    if not raw:
        return None
    token = raw.strip().strip('"').strip("'")
    return token or None


def _output_dir() -> Path:
    raw = os.getenv("TEMPLATE_OUTPUT_DIR", "").strip()
    if raw:
        path = Path(raw).expanduser()
        if not path.is_absolute():
            path = (ENGINE_DIR / path).resolve()
        else:
            path = path.resolve()
        return path
    return (REPO_ROOT / "data" / "generated").resolve()


class Settings(BaseModel):
    output_dir: Path
    copilot_github_token: str | None
    copilot_model: str
    host: str = "127.0.0.1"
    port: int = 8001


def get_settings() -> Settings:
    _load_env_files()
    token = (
        _clean_token(os.getenv("COPILOT_GITHUB_TOKEN"))
        or _clean_token(os.getenv("GH_TOKEN"))
        or _clean_token(os.getenv("GITHUB_TOKEN"))
    )
    return Settings(
        output_dir=_output_dir(),
        copilot_github_token=token,
        copilot_model=os.getenv("COPILOT_MODEL", "auto"),
        host=os.getenv("HOST", "127.0.0.1").strip() or "127.0.0.1",
        port=int(os.getenv("PORT", "8001")),
    )
