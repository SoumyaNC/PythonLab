from __future__ import annotations

import asyncio
import json
import logging
import re
import tempfile

logger = logging.getLogger(__name__)
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

REQUIRED_TF_FILES = ("main.tf", "variables.tf", "outputs.tf", "provider.tf")


class CopilotNotConfigured(RuntimeError):
    pass


@dataclass
class CopilotTurn:
    text: str
    files: dict[str, str] = field(default_factory=dict)


def extract_json(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("Copilot response did not contain JSON.")
    return json.loads(cleaned[start : end + 1])


def coerce_text(result: Any) -> str:
    if result is None:
        return ""
    if isinstance(result, str):
        return result
    for attr in ("content", "text", "output_text", "message"):
        value = getattr(result, attr, None)
        if isinstance(value, str) and value.strip():
            return value
    if isinstance(result, dict):
        for key in ("content", "text", "output_text", "message"):
            value = result.get(key)
            if isinstance(value, str) and value.strip():
                return value
    return str(result)


def files_from_json(payload: dict[str, Any]) -> dict[str, str]:
    blob = payload.get("files") if isinstance(payload.get("files"), dict) else payload
    out: dict[str, str] = {}
    for name in REQUIRED_TF_FILES:
        value = blob.get(name)
        if isinstance(value, str) and value.strip():
            out[name] = value
    return out


def files_from_fences(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    pattern = re.compile(
        r"```(?:hcl|tf|terraform)?[^\n]*\n(?:#\s*)?(?:filename:\s*)?("
        + "|".join(re.escape(n) for n in REQUIRED_TF_FILES)
        + r")\s*\n(.*?)```",
        re.DOTALL | re.IGNORECASE,
    )
    for match in pattern.finditer(text):
        out[match.group(1).lower()] = match.group(2).strip() + "\n"
    for name in REQUIRED_TF_FILES:
        if name in out:
            continue
        tagged = re.compile(
            rf"```(?:hcl|tf|terraform)?[^\n]*{re.escape(name)}[^\n]*\n(.*?)```",
            re.DOTALL | re.IGNORECASE,
        )
        match = tagged.search(text)
        if match:
            out[name] = match.group(1).strip() + "\n"
    return out


def merge_tf_files(*groups: dict[str, str]) -> dict[str, str]:
    merged: dict[str, str] = {}
    for group in groups:
        for name, content in group.items():
            if name in REQUIRED_TF_FILES and isinstance(content, str) and content.strip():
                merged[name] = content if content.endswith("\n") else content + "\n"
    return merged


def read_tf_dir(path: Path) -> dict[str, str]:
    files: dict[str, str] = {}
    for name in REQUIRED_TF_FILES:
        target = path / name
        if target.exists():
            text = target.read_text(encoding="utf-8")
            if text.strip():
                files[name] = text
    return files


async def collect_response(session: Any, prompt: str, timeout_seconds: int) -> str:
    from copilot.session_events import AssistantMessageData, SessionErrorData, SessionIdleData

    done = asyncio.Event()
    chunks: list[str] = []
    errors: list[str] = []

    def on_event(event: Any) -> None:
        data = getattr(event, "data", None)
        if isinstance(data, AssistantMessageData):
            content = getattr(data, "content", None)
            if content:
                chunks.append(str(content))
        elif isinstance(data, SessionErrorData):
            errors.append(getattr(data, "message", None) or str(data))
            done.set()
        elif isinstance(data, SessionIdleData):
            done.set()

    session.on(on_event)
    try:
        await session.send(prompt, agent_mode="autopilot")
    except TypeError:
        await session.send(prompt)
    await asyncio.wait_for(done.wait(), timeout=timeout_seconds)
    if errors:
        raise RuntimeError(errors[0])
    return "\n".join(chunks).strip()


async def run_copilot_turn(
    *,
    token: str | None,
    model: str,
    prompt: str,
    working_files: dict[str, str] | None = None,
    working_directory: Path | None = None,
    system_append: str = "",
    timeout_seconds: int = 180,
) -> CopilotTurn:
    if not token:
        raise CopilotNotConfigured(
            "COPILOT_GITHUB_TOKEN is not set. GitHub Copilot SDK cannot generate templates."
        )
    try:
        from copilot import CopilotClient
        from copilot.session import PermissionHandler
    except Exception as exc:
        raise RuntimeError(
            "github-copilot-sdk is not available. Activate TemplateEngine\\.venv "
            f"before starting the app ({exc})"
        ) from exc

    tmp_ctx = None
    if working_directory is None:
        tmp_ctx = tempfile.TemporaryDirectory(prefix="template-engine-copilot-")
        tmp_path = Path(tmp_ctx.name)
    else:
        tmp_path = Path(working_directory)
        tmp_path.mkdir(parents=True, exist_ok=True)
    try:
        for name, content in (working_files or {}).items():
            (tmp_path / name).write_text(content, encoding="utf-8")
        logger.info("Starting Copilot SDK session model=%s dir=%s", model, tmp_path)
        try:
            async with CopilotClient(
                github_token=token,
                working_directory=str(tmp_path),
                use_logged_in_user=False,
            ) as client:
                session_kwargs: dict[str, Any] = {
                    "on_permission_request": PermissionHandler.approve_all,
                    "model": model,
                    "working_directory": str(tmp_path),
                }
                if system_append:
                    session_kwargs["system_message"] = {"mode": "append", "content": system_append}
                async with await client.create_session(**session_kwargs) as session:
                    text = await collect_response(session, prompt, timeout_seconds)
        except asyncio.TimeoutError as exc:
            raise TimeoutError(
                f"Copilot SDK timed out after {timeout_seconds}s while generating or validating files"
            ) from exc
        except Exception:
            logger.exception("Copilot SDK session failed")
            raise
        disk = read_tf_dir(tmp_path)
        logger.info("Copilot SDK finished files=%s text_len=%s", list(disk), len(text or ""))
    finally:
        if tmp_ctx is not None:
            tmp_ctx.cleanup()
    return CopilotTurn(text=text or "", files=disk)
