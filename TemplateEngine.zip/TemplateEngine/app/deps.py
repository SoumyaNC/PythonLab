from __future__ import annotations

from app.generator import TemplateGenerator, build_generator


def get_generator() -> TemplateGenerator:
    return build_generator()
