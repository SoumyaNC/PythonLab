from __future__ import annotations

import logging
import re
import shutil
from abc import ABC, abstractmethod
from pathlib import Path

logger = logging.getLogger(__name__)

from app.catalog import UnknownAzureResource, known_azurerm_types, resolve_azure_resource
from app.config import get_settings
from app.copilot_runtime import (
    REQUIRED_TF_FILES,
    CopilotNotConfigured,
    extract_json,
    files_from_fences,
    files_from_json,
    merge_tf_files,
    run_copilot_turn,
)
from app.writer import job_dir, read_files, read_spec, require_new_job_dir, write_files


def _folder_exists(root: Path, template_id: str) -> bool:
    try:
        return job_dir(root, template_id).exists()
    except Exception:
        return False

RESOURCE_RE = re.compile(r'resource\s+"([^"]+)"\s+"([^"]+)"', re.MULTILINE)

GENERATE_SYSTEM = """
You generate production-quality Terraform modules for Azure using the azurerm provider.
Create these files in the working directory: main.tf, variables.tf, outputs.tf, provider.tf.
Do not create terraform.tfvars, .terraform/, or README files.
Follow Azure and Terraform best practices: HTTPS-only, TLS 1.2+, no public access by default,
every variable has type + description, no hardcoded subscription/resource-group/name/SKU values.
Also return JSON with the four file contents as keys: main.tf, variables.tf, outputs.tf, provider.tf.
"""

GENERATE_PROMPT = """Create a standard Terraform module for this Azure resource type.

Resource type: {resource_type}
azurerm resource types to use: {azurerm_types}
Display name: {name}
Admin notes: {notes}

Do not invent a different Azure product. If the requested type is not a real Azure resource, do not write files.

Requirements:
- azurerm provider pinned with a version constraint in provider.tf
- provider "azurerm" {{ features {{}} }}
- Parameterize names, location, resource group, SKU/tier, tags
- Secure defaults (HTTPS only, public access disabled where applicable, min TLS 1.2)
- Useful outputs (id, name, and key endpoints)
- Valid HCL only
- Use only these azurerm resources (plus supporting resources they require): {azurerm_types}

Write the four files to the working directory, then output JSON:
{{
  "main.tf": "...",
  "variables.tf": "...",
  "outputs.tf": "...",
  "provider.tf": "..."
}}
"""

REGENERATE_PROMPT = """The working directory already has a Terraform module that was generated earlier.

Original resource type: {resource_type}
Original notes: {notes}
Previous corrections: {previous}

The admin says this is wrong. Apply this correction; do not start from scratch unless the
correction requires a different resource:
{correction}

Update main.tf, variables.tf, outputs.tf, and provider.tf in the working directory.
Keep secure defaults and variable descriptions.
Then output JSON with the four file contents as keys.
"""


def parse_resources(main_tf: str) -> list[str]:
    return [m.group(1) for m in RESOURCE_RE.finditer(main_tf)]


class TemplateGenerator(ABC):
    @abstractmethod
    async def generate(
        self,
        *,
        template_id: str,
        resource_type: str,
        name: str,
        notes: str = "",
    ) -> dict: ...

    @abstractmethod
    async def regenerate(
        self,
        *,
        template_id: str,
        correction: str,
        resource_type: str = "",
        notes: str = "",
        files: dict[str, str] | None = None,
    ) -> dict: ...


class CopilotTemplateGenerator(TemplateGenerator):
    def __init__(self, token: str | None, model: str, output_dir: Path):
        self.token = token
        self.model = model
        self.output_dir = output_dir

    async def generate(
        self,
        *,
        template_id: str,
        resource_type: str,
        name: str,
        notes: str = "",
    ) -> dict:
        display = (name or "").strip()
        if not display:
            raise ValueError("name is required")
        resolved = resolve_azure_resource(resource_type)
        prompt = GENERATE_PROMPT.format(
            resource_type=resolved.name,
            azurerm_types=", ".join(resolved.azurerm_types),
            name=display,
            notes=notes.strip() or "(none)",
        )
        target = require_new_job_dir(self.output_dir, template_id)
        target.mkdir(parents=True)
        try:
            files = await self._complete(prompt, working_files=None, working_directory=target)
            self._assert_matches(files, resolved.name, list(resolved.azurerm_types))
        except Exception:
            logger.exception("Template generate failed id=%s resource_type=%s", template_id, resolved.name)
            if target.exists() and not any(target.glob("*.tf")):
                shutil.rmtree(target, ignore_errors=True)
            raise
        spec = {
            "id": template_id,
            "resource_type": resolved.name,
            "category": resolved.category,
            "azurerm_types": list(resolved.azurerm_types),
            "name": display,
            "notes": notes.strip(),
            "corrections": [],
        }
        path = write_files(self.output_dir, template_id, files, spec)
        return _payload(
            template_id,
            resolved.name,
            resolved.category,
            list(resolved.azurerm_types),
            path,
            files,
            name=display,
        )

    async def regenerate(
        self,
        *,
        template_id: str,
        correction: str,
        resource_type: str = "",
        notes: str = "",
        files: dict[str, str] | None = None,
    ) -> dict:
        spec = read_spec(self.output_dir, template_id)
        previous_files = read_files(self.output_dir, template_id) if _folder_exists(self.output_dir, template_id) else {}
        if files:
            previous_files = {**previous_files, **{k: v for k, v in files.items() if v and str(v).strip()}}
        if not previous_files:
            raise FileNotFoundError(f"No generated Terraform files found for id '{template_id}'.")
        resolved_name = (resource_type or spec.get("resource_type") or "").strip()
        if not resolved_name:
            raise UnknownAzureResource("Resource type is required to regenerate.")
        resolved = resolve_azure_resource(resolved_name)
        previous = spec.get("corrections") or []
        prompt = REGENERATE_PROMPT.format(
            resource_type=resolved.name,
            notes=(notes or spec.get("notes") or "").strip() or "(none)",
            previous="; ".join(previous) if previous else "(none)",
            correction=correction.strip(),
        )
        target = job_dir(self.output_dir, template_id)
        files = await self._complete(prompt, working_files=previous_files, working_directory=target)
        self._assert_matches(files, resolved.name, list(resolved.azurerm_types))
        next_spec = {
            **spec,
            "id": template_id,
            "resource_type": resolved.name,
            "category": resolved.category,
            "azurerm_types": list(resolved.azurerm_types),
            "notes": (notes or spec.get("notes") or "").strip(),
            "corrections": list(previous) + [correction.strip()],
        }
        path = write_files(self.output_dir, template_id, files, next_spec)
        return _payload(
            template_id,
            resolved.name,
            resolved.category,
            list(resolved.azurerm_types),
            path,
            files,
            name=str(next_spec.get("name") or ""),
        )

    def _assert_matches(self, files: dict[str, str], resource_type: str, expected: list[str]) -> None:
        detected = parse_resources(files.get("main.tf", ""))
        allowed = known_azurerm_types()
        if not any(item in allowed for item in detected):
            raise UnknownAzureResource(
                f"Copilot did not produce a recognized Azure resource for '{resource_type}'."
            )
        if not any(item in expected for item in detected):
            raise UnknownAzureResource(
                f"Generated Terraform does not match Azure resource '{resource_type}'. "
                f"Found: {', '.join(detected) or 'none'}."
            )

    async def _complete(
        self,
        prompt: str,
        working_files: dict[str, str] | None,
        working_directory: Path,
    ) -> dict[str, str]:
        turn = await run_copilot_turn(
            token=self.token,
            model=self.model,
            prompt=prompt,
            working_files=working_files,
            working_directory=working_directory,
            system_append=GENERATE_SYSTEM,
            timeout_seconds=180,
        )
        from_json: dict[str, str] = {}
        try:
            from_json = files_from_json(extract_json(turn.text))
        except Exception:
            from_json = {}
        merged = merge_tf_files(from_json, files_from_fences(turn.text), turn.files)
        missing = [name for name in REQUIRED_TF_FILES if name not in merged]
        if missing:
            raise RuntimeError(
                "Copilot did not produce all required Terraform files "
                f"({', '.join(missing)})."
            )
        return {name: merged[name] for name in REQUIRED_TF_FILES}


def _payload(
    template_id: str,
    resource_type: str,
    category: str,
    azurerm_types: list[str],
    path: Path,
    files: dict[str, str],
    *,
    name: str,
) -> dict:
    return {
        "id": template_id,
        "name": name,
        "resource_type": resource_type,
        "category": category,
        "azurerm_types": azurerm_types,
        "output_dir": str(path),
        "files": [filename for filename in REQUIRED_TF_FILES if filename in files],
    }


def build_generator() -> TemplateGenerator:
    settings = get_settings()
    return CopilotTemplateGenerator(
        settings.copilot_github_token,
        settings.copilot_model,
        settings.output_dir,
    )


__all__ = [
    "TemplateGenerator",
    "CopilotTemplateGenerator",
    "CopilotNotConfigured",
    "build_generator",
]
