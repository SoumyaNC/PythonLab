from __future__ import annotations

import logging

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware

from app.catalog import UnknownAzureResource, list_azure_resources
from app.config import get_settings
from app.copilot_runtime import REQUIRED_TF_FILES, CopilotNotConfigured
from app.deps import get_generator
from app.generator import TemplateGenerator
from app.models import GenerateRequest, RegenerateRequest
from app.writer import (
    FolderExists,
    InvalidTemplateId,
    TemplateNotFound,
    job_dir,
    list_tf_names,
    read_spec,
    require_new_job_dir,
    validate_id,
)

logger = logging.getLogger(__name__)


def _safe_error(exc: BaseException) -> str:
    text = str(exc).strip() or type(exc).__name__
    if "resource \"" in text or "variable \"" in text or "```" in text:
        return f"{type(exc).__name__}: Copilot failed while generating Terraform files."
    return text[:500]


def _public_result(payload: dict, *, output_dir: str | None = None) -> dict:
    """API responses never include Terraform file bodies."""
    names = payload.get("files")
    if isinstance(names, dict):
        names = [name for name in REQUIRED_TF_FILES if name in names]
    elif isinstance(names, list):
        names = [name for name in names if isinstance(name, str) and name in REQUIRED_TF_FILES]
    else:
        names = []
    return {
        "id": payload.get("id", ""),
        "name": payload.get("name", ""),
        "resource_type": payload.get("resource_type", ""),
        "category": payload.get("category", ""),
        "azurerm_types": list(payload.get("azurerm_types") or []),
        "output_dir": output_dir or payload.get("output_dir") or "",
        "files": names,
        **({"message": payload["message"]} if payload.get("message") else {}),
    }


def create_app() -> FastAPI:
    settings = get_settings()
    settings.output_dir.mkdir(parents=True, exist_ok=True)
    app = FastAPI(
        title="TemplateEngine",
        version="0.1.0",
        description="Standalone Azure Terraform generator. Writes main.tf, variables.tf, "
        "outputs.tf, and provider.tf under TEMPLATE_OUTPUT_DIR/<id>/.",
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Content-Type", "Accept"],
    )

    @app.get("/api/health")
    def health() -> dict:
        live = get_settings()
        copilot_sdk = False
        try:
            import copilot  # noqa: F401

            copilot_sdk = True
        except Exception:
            copilot_sdk = False
        return {
            "ok": True,
            "service": "TemplateEngine",
            "output_dir": str(live.output_dir),
            "copilot_token_configured": bool(live.copilot_github_token),
            "copilot_sdk_available": copilot_sdk,
        }

    @app.get("/api/resource-types")
    def resource_types() -> dict:
        return {
            "resource_types": [
                {"name": item.name, "category": item.category}
                for item in list_azure_resources()
            ]
        }

    @app.get("/api/templates/{template_id}")
    def get_template(template_id: str) -> dict:
        live = get_settings()
        try:
            names = list_tf_names(live.output_dir, template_id)
        except InvalidTemplateId as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except TemplateNotFound as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        spec = read_spec(live.output_dir, template_id)
        path = job_dir(live.output_dir, template_id)
        if not names:
            raise HTTPException(status_code=404, detail=f"No generated template found for id '{template_id}'.")
        return _public_result(
            {
                "id": validate_id(template_id),
                "name": spec.get("name", ""),
                "resource_type": spec.get("resource_type", ""),
                "category": spec.get("category", ""),
                "azurerm_types": spec.get("azurerm_types", []),
                "files": names,
            },
            output_dir=str(path),
        )

    @app.post("/api/generate")
    async def generate(
        payload: GenerateRequest,
        generator: TemplateGenerator = Depends(get_generator),
    ) -> dict:
        try:
            validate_id(payload.id)
            name = payload.name.strip()
            if not name:
                raise HTTPException(status_code=400, detail="name is required")
            live = get_settings()
            require_new_job_dir(live.output_dir, payload.id.strip())
            result = await generator.generate(
                template_id=payload.id.strip(),
                resource_type=payload.resource_type,
                name=name,
                notes=payload.notes,
            )
            return _public_result(result)
        except InvalidTemplateId as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except FolderExists as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "message": str(exc),
                    "id": exc.template_id,
                    "output_dir": str(exc.path),
                },
            ) from exc
        except UnknownAzureResource as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except CopilotNotConfigured as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except HTTPException:
            raise
        except Exception as exc:
            logger.exception("Template generation failed")
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=_safe_error(exc),
            ) from exc

    @app.post("/api/regenerate")
    async def regenerate(
        payload: RegenerateRequest,
        generator: TemplateGenerator = Depends(get_generator),
    ) -> dict:
        if not payload.correction.strip():
            raise HTTPException(status_code=400, detail="Correction text is required")
        try:
            result = await generator.regenerate(
                template_id=payload.id.strip(),
                correction=payload.correction,
                resource_type=payload.resource_type,
                notes=payload.notes,
                files=payload.files,
            )
            return _public_result(result)
        except InvalidTemplateId as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except TemplateNotFound as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except UnknownAzureResource as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except CopilotNotConfigured as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        except Exception as exc:
            logger.exception("Template regeneration failed")
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=_safe_error(exc),
            ) from exc

    return app


app = create_app()
