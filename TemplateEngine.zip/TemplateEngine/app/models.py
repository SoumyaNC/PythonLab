from __future__ import annotations

from pydantic import BaseModel, Field, field_validator


class GenerateRequest(BaseModel):
    id: str = Field(..., description="Folder name created under TEMPLATE_OUTPUT_DIR")
    resource_type: str
    name: str = Field(..., min_length=1, description="Display name; required before generation")
    notes: str = ""

    @field_validator("id", "resource_type", "name")
    @classmethod
    def not_blank(cls, value: str, info) -> str:
        text = (value or "").strip()
        if not text:
            raise ValueError(f"{info.field_name} is required")
        return text


class RegenerateRequest(BaseModel):
    id: str
    correction: str
    resource_type: str = ""
    notes: str = ""
    files: dict[str, str] | None = None
