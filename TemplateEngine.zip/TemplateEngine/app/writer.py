from __future__ import annotations

import json
import re
from pathlib import Path

from app.copilot_runtime import REQUIRED_TF_FILES

ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
SPEC_FILE = "spec.json"


class InvalidTemplateId(ValueError):
    pass


class TemplateNotFound(FileNotFoundError):
    pass


class FolderExists(ValueError):
    def __init__(self, template_id: str, path: Path):
        self.template_id = template_id
        self.path = path
        super().__init__(
            f"A folder already exists with id '{template_id}' at {path}. "
            "Use a different id, or POST /api/regenerate to update the existing template."
        )


def validate_id(raw: str) -> str:
    text = (raw or "").strip()
    if not ID_PATTERN.fullmatch(text):
        raise InvalidTemplateId(
            "id must be 1-128 characters: letters, digits, dot, underscore, or hyphen, "
            "and must start with a letter or digit."
        )
    return text


def job_dir(root: Path, template_id: str) -> Path:
    safe_id = validate_id(template_id)
    root = root.resolve()
    path = (root / safe_id).resolve()
    if not path.is_relative_to(root) or path == root:
        raise InvalidTemplateId("id does not resolve inside the output directory.")
    return path


def require_new_job_dir(root: Path, template_id: str) -> Path:
    path = job_dir(root, template_id)
    if path.exists():
        raise FolderExists(validate_id(template_id), path)
    return path


def write_files(root: Path, template_id: str, files: dict[str, str], spec: dict | None = None) -> Path:
    path = job_dir(root, template_id)
    path.mkdir(parents=True, exist_ok=True)
    missing = [name for name in REQUIRED_TF_FILES if name not in files or not str(files[name]).strip()]
    if missing:
        raise ValueError(f"Missing Terraform files: {', '.join(missing)}")
    for name in REQUIRED_TF_FILES:
        content = files[name]
        if not content.endswith("\n"):
            content += "\n"
        (path / name).write_text(content, encoding="utf-8")
    if spec is not None:
        (path / SPEC_FILE).write_text(json.dumps(spec, indent=2) + "\n", encoding="utf-8")
    return path


def list_tf_names(root: Path, template_id: str) -> list[str]:
    path = job_dir(root, template_id)
    if not path.exists():
        raise TemplateNotFound(f"No generated template found for id '{template_id}'.")
    names: list[str] = []
    for name in REQUIRED_TF_FILES:
        target = path / name
        if target.is_file() and target.stat().st_size > 0:
            names.append(name)
    return names


def read_files(root: Path, template_id: str) -> dict[str, str]:
    path = job_dir(root, template_id)
    if not path.exists():
        raise TemplateNotFound(f"No generated template found for id '{template_id}'.")
    out: dict[str, str] = {}
    for name in REQUIRED_TF_FILES:
        target = path / name
        if target.exists():
            text = target.read_text(encoding="utf-8")
            if text.strip():
                out[name] = text
    return out


def read_spec(root: Path, template_id: str) -> dict:
    path = job_dir(root, template_id) / SPEC_FILE
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}
