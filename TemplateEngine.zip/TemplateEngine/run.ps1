$here = $PSScriptRoot
$python = Join-Path $here ".venv\Scripts\python.exe"
$venv = Join-Path $here ".venv"

if (-not (Test-Path $python)) {
  Write-Host "Creating TemplateEngine venv..."
  py -3 -m venv $venv
  if (-not (Test-Path $python)) {
    Write-Error "Failed to create $venv"
    exit 1
  }
  & $python -m pip install --upgrade pip
  & $python -m pip install -r (Join-Path $here "requirements.txt")
}

Set-Location $here
& $python -c "import copilot" 2>$null
if ($LASTEXITCODE -ne 0) {
  Write-Host "Installing TemplateEngine dependencies into local venv..."
  & $python -m pip install -r (Join-Path $here "requirements.txt")
}

Write-Host "Starting TemplateEngine on http://127.0.0.1:8001 (venv: $venv)"
& $python -m uvicorn app.main:app --host 127.0.0.1 --port 8001
