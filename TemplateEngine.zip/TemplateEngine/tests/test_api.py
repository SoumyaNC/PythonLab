from pathlib import Path
import os
import sys
import tempfile

from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.copilot_runtime import REQUIRED_TF_FILES
from app.deps import get_generator
from app.main import app
from app.writer import write_files


SAMPLE = {
    "main.tf": 'resource "azurerm_linux_web_app" "app" {\n  name = var.name\n}\n',
    "variables.tf": 'variable "name" { type = string }\n',
    "outputs.tf": 'output "id" { value = "x" }\n',
    "provider.tf": 'terraform {\n  required_providers {\n    azurerm = { source = "hashicorp/azurerm" }\n  }\n}\nprovider "azurerm" { features {} }\n',
}


class FakeGenerator:
    def __init__(self, output_dir: Path):
        self.output_dir = output_dir

    async def generate(self, *, template_id: str, resource_type: str, name: str = "", notes: str = "") -> dict:
        from app.catalog import resolve_azure_resource

        resolved = resolve_azure_resource(resource_type)
        path = write_files(
            self.output_dir,
            template_id,
            SAMPLE,
            spec={
                "id": template_id,
                "resource_type": resolved.name,
                "category": resolved.category,
                "azurerm_types": list(resolved.azurerm_types),
                "name": name or resolved.name,
                "notes": notes,
                "corrections": [],
            },
        )
        return {
            "id": template_id,
            "name": name,
            "resource_type": resolved.name,
            "category": resolved.category,
            "azurerm_types": list(resolved.azurerm_types),
            "output_dir": str(path),
            "files": list(REQUIRED_TF_FILES),
        }

    async def regenerate(
        self,
        *,
        template_id: str,
        correction: str,
        resource_type: str = "",
        notes: str = "",
        files: dict[str, str] | None = None,
    ) -> dict:
        return await self.generate(
            template_id=template_id,
            resource_type=resource_type or "App Service",
            name="",
            notes=correction,
        )


def test_health():
    with TestClient(app) as client:
        res = client.get("/api/health")
        assert res.status_code == 200
        body = res.json()
        assert body["ok"] is True
        assert body["service"] == "TemplateEngine"


def test_generate_writes_folder():
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["TEMPLATE_OUTPUT_DIR"] = tmp
        fake = FakeGenerator(Path(tmp))
        app.dependency_overrides[get_generator] = lambda: fake
        try:
            with TestClient(app) as client:
                res = client.post(
                    "/api/generate",
                    json={
                        "id": "job-42",
                        "name": "Linux Web App",
                        "resource_type": "App Service",
                        "notes": "Linux only",
                    },
                )
                assert res.status_code == 200, res.text
                body = res.json()
                assert body["id"] == "job-42"
                assert body["name"] == "Linux Web App"
                assert body["resource_type"] == "App Service"
                assert body["files"] == list(REQUIRED_TF_FILES)
                assert (Path(tmp) / "job-42" / "main.tf").exists()
                got = client.get("/api/templates/job-42")
                assert got.status_code == 200
                listed = got.json()["files"]
                assert got.json()["name"] == "Linux Web App"
                assert listed == list(REQUIRED_TF_FILES)
                assert all(isinstance(name, str) for name in listed)
                assert "variable \"name\"" not in got.text
                assert "variable \"name\"" not in res.text
        finally:
            app.dependency_overrides.clear()


def test_generate_rejects_unknown_type():
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["TEMPLATE_OUTPUT_DIR"] = tmp
        app.dependency_overrides[get_generator] = lambda: FakeGenerator(Path(tmp))
        try:
            with TestClient(app) as client:
                res = client.post(
                    "/api/generate",
                    json={"id": "job-1", "name": "Nope", "resource_type": "Banana Cluster"},
                )
                assert res.status_code == 400
        finally:
            app.dependency_overrides.clear()


def test_generate_rejects_existing_folder():
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["TEMPLATE_OUTPUT_DIR"] = tmp
        (Path(tmp) / "job-42").mkdir()
        app.dependency_overrides[get_generator] = lambda: FakeGenerator(Path(tmp))
        try:
            with TestClient(app) as client:
                res = client.post(
                    "/api/generate",
                    json={"id": "job-42", "name": "Linux Web App", "resource_type": "App Service"},
                )
                assert res.status_code == 409, res.text
                detail = res.json()["detail"]
                assert "already exists" in detail["message"]
                assert detail["id"] == "job-42"
                assert "job-42" in detail["output_dir"]
        finally:
            app.dependency_overrides.clear()


def test_generate_requires_name():
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["TEMPLATE_OUTPUT_DIR"] = tmp
        app.dependency_overrides[get_generator] = lambda: FakeGenerator(Path(tmp))
        try:
            with TestClient(app) as client:
                missing = client.post("/api/generate", json={"id": "job-1", "resource_type": "App Service"})
                assert missing.status_code in (400, 422), missing.text
                blank = client.post(
                    "/api/generate",
                    json={"id": "job-1", "name": "   ", "resource_type": "App Service"},
                )
                assert blank.status_code in (400, 422), blank.text
        finally:
            app.dependency_overrides.clear()


def test_generate_rejects_bad_id():
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["TEMPLATE_OUTPUT_DIR"] = tmp
        app.dependency_overrides[get_generator] = lambda: FakeGenerator(Path(tmp))
        try:
            with TestClient(app) as client:
                res = client.post(
                    "/api/generate",
                    json={"id": "../etc", "name": "Linux Web App", "resource_type": "App Service"},
                )
                assert res.status_code == 400
        finally:
            app.dependency_overrides.clear()


if __name__ == "__main__":
    test_health()
    test_generate_writes_folder()
    test_generate_rejects_unknown_type()
    test_generate_rejects_existing_folder()
    test_generate_requires_name()
    test_generate_rejects_bad_id()
    print("ok")
