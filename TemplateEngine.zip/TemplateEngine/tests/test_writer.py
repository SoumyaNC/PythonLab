from pathlib import Path
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.writer import FolderExists, InvalidTemplateId, job_dir, read_files, require_new_job_dir, write_files


SAMPLE = {
    "main.tf": 'resource "azurerm_linux_web_app" "app" {}\n',
    "variables.tf": 'variable "name" { type = string }\n',
    "outputs.tf": 'output "id" { value = "x" }\n',
    "provider.tf": 'provider "azurerm" { features {} }\n',
}


def test_write_creates_id_folder():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        path = write_files(root, "app-service-1", SAMPLE, spec={"resource_type": "App Service"})
        assert path == root / "app-service-1"
        assert (path / "main.tf").exists()
        assert (path / "spec.json").exists()
        files = read_files(root, "app-service-1")
        assert set(files) == set(SAMPLE)


def test_rejects_path_traversal():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        try:
            job_dir(root, "../escape")
            raise AssertionError("expected InvalidTemplateId")
        except InvalidTemplateId:
            pass
        try:
            job_dir(root, "foo/bar")
            raise AssertionError("expected InvalidTemplateId")
        except InvalidTemplateId:
            pass


def test_rejects_existing_folder():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        write_files(root, "app-service-1", SAMPLE)
        try:
            require_new_job_dir(root, "app-service-1")
            raise AssertionError("expected FolderExists")
        except FolderExists as exc:
            assert "already exists" in str(exc)
            assert "app-service-1" in str(exc)


if __name__ == "__main__":
    test_write_creates_id_folder()
    test_rejects_path_traversal()
    test_rejects_existing_folder()
    print("ok")
