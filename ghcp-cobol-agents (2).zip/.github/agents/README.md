# GitHub Copilot Custom Agents for COBOL Reverse Engineering

These agents are designed to be **more generic** and robust than a single-project prompt.

## Agents

| Agent File                      | Purpose |
|--------------------------------|---------|
| `cobol-relationship-mapper.md` | Discovers source/copybook locations, parses CALL/COPY/SELECT, and generates relationship diagrams + intermediate JSON/Mermaid |
| `cobol-doc-generator.md`       | Consumes the mapper output and produces one consolidated LMA-style reverse-engineering document |

## How to Use

1. Place the `.github/agents/` folder in the root of any COBOL project.
2. Open the project in VS Code with GitHub Copilot Chat.
3. Run **COBOL Doc Generator** (it will use the Relationship Mapper).

## Output Locations

- Intermediate artifacts: `DOC/intermediate/`
- Final single document: `DOC/RE-COBOL-SYSTEM.md`

## What “Closer to Production-Grade” Means Here

- Automatic discovery of source and copybook folders (not hardcoded to one structure)
- Dialect-aware parsing instructions
- Explicit validation and “do not invent” rules
- Structured intermediate files for auditability
- Single consolidated document with consistent LMA-style sections

**Important limitation**: These are still LLM instruction agents, not a deterministic COBOL parser. For true production-grade reverse engineering, pair them with a real static analysis tool or parser. They are significantly stronger and more reusable than the previous project-specific versions.